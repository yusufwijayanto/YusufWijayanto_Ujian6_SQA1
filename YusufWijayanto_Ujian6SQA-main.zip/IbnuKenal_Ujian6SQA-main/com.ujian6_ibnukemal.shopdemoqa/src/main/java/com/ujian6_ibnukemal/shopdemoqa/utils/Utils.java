package com.ujian6_ibnukemal.shopdemoqa.utils;

public class Utils {

	public static int testCount = 0;
}
